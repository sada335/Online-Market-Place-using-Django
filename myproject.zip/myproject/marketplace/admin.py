from django.contrib import admin
from .models import MarketItem

admin.site.register(MarketItem)
